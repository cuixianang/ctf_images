function checkKey() {
    const input = document.getElementById("keyInput").value;
    const correctKey = "unfreeze_me";
    if (input === correctKey) {
        document.getElementById("result").innerText = "✅ System Unlocked! Flag: IGNITE{" + input + "}";
        document.body.style.backgroundColor = "#002c00";
    } else {
        document.getElementById("result").innerText = "❌ Incorrect key. Try again.";
    }
}
