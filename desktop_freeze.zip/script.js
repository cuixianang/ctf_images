function checkKey() {
    const input = document.getElementById("keyInput").value;
    const secret = atob("aW5zcGVjdF90b191bmxvY2s="); 
    const flag = "IGNITE{" + secret + "}";
    
    if (input === secret) {
        document.getElementById("result").innerText = "✅ Unlocked! Flag: " + flag;
        document.body.style.backgroundColor = "#002e00";
    } else {
        document.getElementById("result").innerText = "❌ Incorrect key.";
    }
}
