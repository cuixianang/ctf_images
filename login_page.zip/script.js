function checkPassword() {
  const password = document.getElementById("passwordInput").value;
  const secret = "12345"; // Hardcoded weak password

  if (password === secret) {
    document.getElementById("result").innerText = "Access Granted!";
  } else {
    document.getElementById("result").innerText = "Access Denied!";
  }

  return false; // Prevent form submission
}
