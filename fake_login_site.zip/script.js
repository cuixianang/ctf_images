
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simulated phishing behavior
    const exfilURL = atob("aHR0cDovL2JhZC5zaXRlL2xvZ2luLnBocD9mbGFnPUlHTklURXtwaGlzaGluZ19zY3JpcHRfcmV2ZWFsZWR9");
    document.getElementById('status').innerText = "Something went wrong. Try again later.";

    console.log("Sending credentials to " + exfilURL);
    // Real phishing would send this via fetch or xhr
});
