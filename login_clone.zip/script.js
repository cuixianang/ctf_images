console.log("Cloned portal loaded.");
